<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index()
    {
        $employees = Employee::latest()->paginate(10);
        return view('employees.index', compact('employees'));
    }

    public function create()
    {
        return view('employees.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'employee_code'           => 'required|unique:employees,employee_code',
            'first_name'              => 'required|string|max:255',
            'last_name'               => 'required|string|max:255',
            'gender'                  => 'required|in:male,female,other',
            'date_of_birth'           => 'required|date',
            'national_id_number'      => 'required|unique:employees,national_id_number',
            'marital_status'          => 'required|in:single,married,divorced',
            'email'                   => 'required|email|unique:employees,email',
            'phone_number'            => 'required|string|max:20',
            'address'                 => 'required|string',
            'city'                    => 'required|string',
            'postal_code'             => 'required|string',
            'department_id'           => 'nullable|integer',
            'job_title'               => 'required|string',
            'employment_type'         => 'required|in:full_time,part_time,contract',
            'join_date'               => 'required|date',
            'base_salary'             => 'required|numeric|min:0',
            'bank_name'               => 'required|string',
            'bank_account_number'     => 'required|string',
            'emergency_contact_name'  => 'required|string',
            'emergency_contact_phone' => 'required|string',
            'profile_picture'         => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'status'                  => 'required|in:active,on_leave,terminated',
        ]);

        if ($request->hasFile('profile_picture')) {
            $validated['profile_picture'] = $request->file('profile_picture')->store('profiles', 'public');
        }

        Employee::create($validated);

        return redirect()->route('employees.index')->with('success', 'บันทึกข้อมูลพนักงานสำเร็จ!');
    }

    // 1. หน้าแสดงรายละเอียดพนักงานแบบเต็ม
    public function show(Employee $employee)
    {
        return view('employees.show', compact('employee'));
    }

    // 2. หน้าฟอร์มแก้ไขข้อมูลพนักงาน
    public function edit(Employee $employee)
    {
        return view('employees.edit', compact('employee'));
    }

    // 3. บันทึกข้อมูลที่แก้ไข
    public function update(Request $request, Employee $employee)
    {
        $validated = $request->validate([
            'employee_code'           => 'required|unique:employees,employee_code,' . $employee->id,
            'first_name'              => 'required|string|max:255',
            'last_name'               => 'required|string|max:255',
            'gender'                  => 'required|in:male,female,other',
            'date_of_birth'           => 'required|date',
            'national_id_number'      => 'required|unique:employees,national_id_number,' . $employee->id,
            'marital_status'          => 'required|in:single,married,divorced',
            'email'                   => 'required|email|unique:employees,email,' . $employee->id,
            'phone_number'            => 'required|string|max:20',
            'address'                 => 'required|string',
            'city'                    => 'required|string',
            'postal_code'             => 'required|string',
            'department_id'           => 'nullable|integer',
            'job_title'               => 'required|string',
            'employment_type'         => 'required|in:full_time,part_time,contract',
            'join_date'               => 'required|date',
            'base_salary'             => 'required|numeric|min:0',
            'bank_name'               => 'required|string',
            'bank_account_number'     => 'required|string',
            'emergency_contact_name'  => 'required|string',
            'emergency_contact_phone' => 'required|string',
            'profile_picture'         => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'status'                  => 'required|in:active,on_leave,terminated',
        ]);

        if ($request->hasFile('profile_picture')) {
            $validated['profile_picture'] = $request->file('profile_picture')->store('profiles', 'public');
        }

        $employee->update($validated);

        return redirect()->route('employees.index')->with('success', 'อัปเดตข้อมูลพนักงานเรียบร้อยแล้ว!');
    }

    // 4. ลบข้อมูลพนักงาน (Soft Delete)
    public function destroy(Employee $employee)
    {
        $employee->delete();
        return redirect()->route('employees.index')->with('success', 'ลบข้อมูลพนักงานเรียบร้อยแล้ว!');
    }
}