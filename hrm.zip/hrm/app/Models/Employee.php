<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employee extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'employee_code',
        'first_name',
        'last_name',
        'gender',
        'date_of_birth',
        'national_id_number',
        'marital_status',
        'email',
        'phone_number',
        'address',
        'city',
        'postal_code',
        'department_id',
        'job_title',
        'employment_type',
        'join_date',
        'base_salary',
        'bank_name',
        'bank_account_number',
        'emergency_contact_name',
        'emergency_contact_phone',
        'profile_picture',
        'status',
    ];
}