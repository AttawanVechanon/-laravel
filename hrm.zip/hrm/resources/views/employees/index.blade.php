<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายการพนักงาน</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">ระบบจัดการพนักงาน (HRM)</h4>
            <a href="{{ route('employees.create') }}" class="btn btn-success btn-sm">+ เพิ่มพนักงานใหม่</a>
        </div>
        <div class="card-body">
            @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>รูปภาพ</th>
                            <th>รหัส</th>
                            <th>ชื่อ-นามสกุล</th>
                            <th>ตำแหน่ง</th>
                            <th>อีเมล</th>
                            <th>เบอร์โทร</th>
                            <th>สถานะ</th>
                            <th class="text-center" style="width: 180px;">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($employees as $employee)
                            <tr>
                                <td class="text-center">
                                    @if ($employee->profile_picture)
                                        <img src="{{ asset('storage/' . $employee->profile_picture) }}" alt="รูปโปรไฟล์" class="rounded-circle" width="45" height="45" style="object-fit: cover;">
                                    @else
                                        <div class="bg-secondary text-white rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 45px; height: 45px; font-size: 14px;">
                                            {{ mb_substr($employee->first_name, 0, 1) }}
                                        </div>
                                    @endif
                                </td>
                                <td>{{ $employee->employee_code }}</td>
                                <td>{{ $employee->first_name }} {{ $employee->last_name }}</td>
                                <td>{{ $employee->job_title }}</td>
                                <td>{{ $employee->email }}</td>
                                <td>{{ $employee->phone_number }}</td>
                                <td>
                                    <span class="badge bg-{{ $employee->status == 'active' ? 'success' : ($employee->status == 'on_leave' ? 'warning' : 'danger') }}">
                                        {{ $employee->status == 'active' ? 'ทำงานอยู่' : ($employee->status == 'on_leave' ? 'ลาพัก' : 'พ้นสภาพ') }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('employees.show', $employee->id) }}" class="btn btn-info btn-sm text-white">ดู</a>
                                    <a href="{{ route('employees.edit', $employee->id) }}" class="btn btn-warning btn-sm text-white">แก้ไข</a>
                                    <form action="{{ route('employees.destroy', $employee->id) }}" method="POST" class="d-inline" onsubmit="return confirm('คุณต้องการลบข้อมูลพนักงานคนนี้ใช่หรือไม่?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm">ลบ</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center text-muted">ยังไม่มีข้อมูลพนักงาน</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            {{ $employees->links() }}
        </div>
    </div>
</div>
</body>
</html>