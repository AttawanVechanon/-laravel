<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายละเอียดพนักงาน</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
    <div class="card shadow-sm">
        <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">รายละเอียดพนักงาน: {{ $employee->first_name }} {{ $employee->last_name }}</h4>
            <a href="{{ route('employees.index') }}" class="btn btn-light btn-sm">กลับหน้าหลัก</a>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-3 text-center">
                    @if ($employee->profile_picture)
                        <img src="{{ asset('storage/' . $employee->profile_picture) }}" class="img-fluid rounded border mb-3" style="max-height: 200px;">
                    @else
                        <div class="bg-secondary text-white rounded d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 150px; height: 150px; font-size: 48px;">
                            {{ mb_substr($employee->first_name, 0, 1) }}
                        </div>
                    @endif
                    <div>
                        <span class="badge bg-{{ $employee->status == 'active' ? 'success' : ($employee->status == 'on_leave' ? 'warning' : 'danger') }} fs-6">
                            {{ $employee->status == 'active' ? 'ทำงานอยู่' : ($employee->status == 'on_leave' ? 'ลาพัก' : 'พ้นสภาพ') }}
                        </span>
                    </div>
                </div>
                <div class="col-md-9">
                    <h5 class="text-primary border-bottom pb-2">1. ข้อมูลส่วนตัว</h5>
                    <div class="row mb-3">
                        <div class="col-md-4"><strong>รหัสพนักงาน:</strong> {{ $employee->employee_code }}</div>
                        <div class="col-md-4"><strong>ชื่อ-นามสกุล:</strong> {{ $employee->first_name }} {{ $employee->last_name }}</div>
                        <div class="col-md-4"><strong>เพศ:</strong> {{ $employee->gender }}</div>
                        <div class="col-md-4 mt-2"><strong>วันเกิด:</strong> {{ $employee->date_of_birth }}</div>
                        <div class="col-md-4 mt-2"><strong>เลขบัตรประชาชน:</strong> {{ $employee->national_id_number }}</div>
                        <div class="col-md-4 mt-2"><strong>สถานะสมรส:</strong> {{ $employee->marital_status }}</div>
                    </div>

                    <h5 class="text-primary border-bottom pb-2">2. ข้อมูลการติดต่อ</h5>
                    <div class="row mb-3">
                        <div class="col-md-6"><strong>อีเมล:</strong> {{ $employee->email }}</div>
                        <div class="col-md-6"><strong>เบอร์โทรศัพท์:</strong> {{ $employee->phone_number }}</div>
                        <div class="col-md-12 mt-2"><strong>ที่อยู่:</strong> {{ $employee->address }}, {{ $employee->city }} {{ $employee->postal_code }}</div>
                    </div>

                    <h5 class="text-primary border-bottom pb-2">3. ข้อมูลการทำงาน</h5>
                    <div class="row mb-3">
                        <div class="col-md-4"><strong>ตำแหน่ง:</strong> {{ $employee->job_title }}</div>
                        <div class="col-md-4"><strong>ประเภทการจ้าง:</strong> {{ $employee->employment_type }}</div>
                        <div class="col-md-4"><strong>วันที่เริ่มงาน:</strong> {{ $employee->join_date }}</div>
                        <div class="col-md-4 mt-2"><strong>เงินเดือนพื้นฐาน:</strong> {{ number_format($employee->base_salary, 2) }} บาท</div>
                    </div>

                    <h5 class="text-primary border-bottom pb-2">4. ธนาคาร และ ผู้ติดต่อฉุกเฉิน</h5>
                    <div class="row mb-3">
                        <div class="col-md-6"><strong>ธนาคาร:</strong> {{ $employee->bank_name }}</div>
                        <div class="col-md-6"><strong>เลขบัญชี:</strong> {{ $employee->bank_account_number }}</div>
                        <div class="col-md-6 mt-2"><strong>ผู้ติดต่อฉุกเฉิน:</strong> {{ $employee->emergency_contact_name }}</div>
                        <div class="col-md-6 mt-2"><strong>เบอร์ติดต่อฉุกเฉิน:</strong> {{ $employee->emergency_contact_phone }}</div>
                    </div>
                </div>
            </div>
            
            <div class="text-end">
                <a href="{{ route('employees.edit', $employee->id) }}" class="btn btn-warning text-white">แก้ไขข้อมูลนี้</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>