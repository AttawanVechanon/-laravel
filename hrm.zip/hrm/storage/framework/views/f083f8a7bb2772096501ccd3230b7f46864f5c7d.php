<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขข้อมูลพนักงาน</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
    <div class="card shadow-sm">
        <div class="card-header bg-warning text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">แก้ไขข้อมูลพนักงาน: <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h4>
            <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-light btn-sm">กลับหน้าหลัก</a>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('employees.update', $employee->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <!-- 1. ข้อมูลส่วนตัว -->
                <h5 class="text-primary border-bottom pb-2 mb-3">1. ข้อมูลส่วนตัว</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label class="form-label">รหัสพนักงาน *</label>
                        <input type="text" name="employee_code" class="form-control" value="<?php echo e(old('employee_code', $employee->employee_code)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">ชื่อ *</label>
                        <input type="text" name="first_name" class="form-control" value="<?php echo e(old('first_name', $employee->first_name)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">นามสกุล *</label>
                        <input type="text" name="last_name" class="form-control" value="<?php echo e(old('last_name', $employee->last_name)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">เพศ *</label>
                        <select name="gender" class="form-select" required>
                            <option value="male" <?php echo e($employee->gender == 'male' ? 'selected' : ''); ?>>ชาย</option>
                            <option value="female" <?php echo e($employee->gender == 'female' ? 'selected' : ''); ?>>หญิง</option>
                            <option value="other" <?php echo e($employee->gender == 'other' ? 'selected' : ''); ?>>อื่นๆ</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">วันเกิด *</label>
                        <input type="date" name="date_of_birth" class="form-control" value="<?php echo e(old('date_of_birth', $employee->date_of_birth)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">เลขบัตรประชาชน *</label>
                        <input type="text" name="national_id_number" class="form-control" value="<?php echo e(old('national_id_number', $employee->national_id_number)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">สถานะสมรส *</label>
                        <select name="marital_status" class="form-select" required>
                            <option value="single" <?php echo e($employee->marital_status == 'single' ? 'selected' : ''); ?>>โสด</option>
                            <option value="married" <?php echo e($employee->marital_status == 'married' ? 'selected' : ''); ?>>แต่งงานแล้ว</option>
                            <option value="divorced" <?php echo e($employee->marital_status == 'divorced' ? 'selected' : ''); ?>>หย่าร้าง</option>
                        </select>
                    </div>
                </div>

                <!-- 2. ข้อมูลการติดต่อ -->
                <h5 class="text-primary border-bottom pb-2 mb-3">2. ข้อมูลการติดต่อ</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label">อีเมล *</label>
                        <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $employee->email)); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">เบอร์โทรศัพท์ *</label>
                        <input type="text" name="phone_number" class="form-control" value="<?php echo e(old('phone_number', $employee->phone_number)); ?>" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">ที่อยู่ *</label>
                        <textarea name="address" class="form-control" rows="2" required><?php echo e(old('address', $employee->address)); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">จังหวัด / เมือง *</label>
                        <input type="text" name="city" class="form-control" value="<?php echo e(old('city', $employee->city)); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">รหัสไปรษณีย์ *</label>
                        <input type="text" name="postal_code" class="form-control" value="<?php echo e(old('postal_code', $employee->postal_code)); ?>" required>
                    </div>
                </div>

                <!-- 3. ข้อมูลการทำงาน -->
                <h5 class="text-primary border-bottom pb-2 mb-3">3. ข้อมูลการทำงาน</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label class="form-label">ตำแหน่งงาน *</label>
                        <input type="text" name="job_title" class="form-control" value="<?php echo e(old('job_title', $employee->job_title)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">ประเภทการจ้าง *</label>
                        <select name="employment_type" class="form-select" required>
                            <option value="full_time" <?php echo e($employee->employment_type == 'full_time' ? 'selected' : ''); ?>>ประจำ (Full-time)</option>
                            <option value="part_time" <?php echo e($employee->employment_type == 'part_time' ? 'selected' : ''); ?>>พาร์ทไทม์ (Part-time)</option>
                            <option value="contract" <?php echo e($employee->employment_type == 'contract' ? 'selected' : ''); ?>>สัญญาจ้าง (Contract)</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">วันที่เริ่มงาน *</label>
                        <input type="date" name="join_date" class="form-control" value="<?php echo e(old('join_date', $employee->join_date)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">เงินเดือนพื้นฐาน *</label>
                        <input type="number" step="0.01" name="base_salary" class="form-control" value="<?php echo e(old('base_salary', $employee->base_salary)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">สถานะพนักงาน *</label>
                        <select name="status" class="form-select" required>
                            <option value="active" <?php echo e($employee->status == 'active' ? 'selected' : ''); ?>>ทำงานอยู่ (Active)</option>
                            <option value="on_leave" <?php echo e($employee->status == 'on_leave' ? 'selected' : ''); ?>>ลาพัก (On Leave)</option>
                            <option value="terminated" <?php echo e($employee->status == 'terminated' ? 'selected' : ''); ?>>พ้นสภาพ (Terminated)</option>
                        </select>
                    </div>
                </div>

                <!-- 4. ข้อมูลการเงินและผู้ติดต่อฉุกเฉิน -->
                <h5 class="text-primary border-bottom pb-2 mb-3">4. ข้อมูลธนาคาร และ ผู้ติดต่อฉุกเฉิน</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label">ชื่อธนาคาร *</label>
                        <input type="text" name="bank_name" class="form-control" value="<?php echo e(old('bank_name', $employee->bank_name)); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">เลขที่บัญชี *</label>
                        <input type="text" name="bank_account_number" class="form-control" value="<?php echo e(old('bank_account_number', $employee->bank_account_number)); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">ชื่อผู้ติดต่อฉุกเฉิน *</label>
                        <input type="text" name="emergency_contact_name" class="form-control" value="<?php echo e(old('emergency_contact_name', $employee->emergency_contact_name)); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">เบอร์ติดต่อฉุกเฉิน *</label>
                        <input type="text" name="emergency_contact_phone" class="form-control" value="<?php echo e(old('emergency_contact_phone', $employee->emergency_contact_phone)); ?>" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">รูปโปรไฟล์ (อัปโหลดใหม่เพื่อเปลี่ยนรูป)</label>
                        <input type="file" name="profile_picture" class="form-control">
                        <?php if($employee->profile_picture): ?>
                            <div class="mt-2">
                                <small class="text-muted">รูปปัจจุบัน:</small><br>
                                <img src="<?php echo e(asset('storage/' . $employee->profile_picture)); ?>" width="80" class="rounded border mt-1">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="text-end">
                    <button type="submit" class="btn btn-warning text-white px-4">อัปเดตข้อมูล</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH D:\laravelnitat\hrm\resources\views/employees/edit.blade.php ENDPATH**/ ?>