<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายการพนักงาน</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">ระบบจัดการพนักงาน (HRM)</h4>
            <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success btn-sm">+ เพิ่มพนักงานใหม่</a>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>รูปภาพ</th>
                            <th>รหัส</th>
                            <th>ชื่อ-นามสกุล</th>
                            <th>ตำแหน่ง</th>
                            <th>อีเมล</th>
                            <th>เบอร์โทร</th>
                            <th>สถานะ</th>
                            <th class="text-center" style="width: 180px;">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center">
                                    <?php if($employee->profile_picture): ?>
                                        <img src="<?php echo e(asset('storage/' . $employee->profile_picture)); ?>" alt="รูปโปรไฟล์" class="rounded-circle" width="45" height="45" style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-secondary text-white rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 45px; height: 45px; font-size: 14px;">
                                            <?php echo e(mb_substr($employee->first_name, 0, 1)); ?>

                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($employee->employee_code); ?></td>
                                <td><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></td>
                                <td><?php echo e($employee->job_title); ?></td>
                                <td><?php echo e($employee->email); ?></td>
                                <td><?php echo e($employee->phone_number); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($employee->status == 'active' ? 'success' : ($employee->status == 'on_leave' ? 'warning' : 'danger')); ?>">
                                        <?php echo e($employee->status == 'active' ? 'ทำงานอยู่' : ($employee->status == 'on_leave' ? 'ลาพัก' : 'พ้นสภาพ')); ?>

                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('employees.show', $employee->id)); ?>" class="btn btn-info btn-sm text-white">ดู</a>
                                    <a href="<?php echo e(route('employees.edit', $employee->id)); ?>" class="btn btn-warning btn-sm text-white">แก้ไข</a>
                                    <form action="<?php echo e(route('employees.destroy', $employee->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('คุณต้องการลบข้อมูลพนักงานคนนี้ใช่หรือไม่?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">ลบ</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">ยังไม่มีข้อมูลพนักงาน</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($employees->links()); ?>

        </div>
    </div>
</div>
</body>
</html><?php /**PATH D:\laravelnitat\hrm\resources\views/employees/index.blade.php ENDPATH**/ ?>