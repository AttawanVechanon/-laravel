<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up(): void
{
    Schema::create('employees', function (Blueprint $table) {
        $table->id();
        
        // ข้อมูลส่วนตัว
        $table->string('employee_code')->unique();
        $table->string('first_name');
        $table->string('last_name');
        $table->enum('gender', ['male', 'female', 'other']);
        $table->date('date_of_birth');
        $table->string('national_id_number')->unique();
        $table->enum('marital_status', ['single', 'married', 'divorced'])->default('single');
        
        // ข้อมูลการติดต่อ
        $table->string('email')->unique();
        $table->string('phone_number');
        $table->text('address');
        $table->string('city');
        $table->string('postal_code');
        
        // ข้อมูลการทำงาน
        $table->foreignId('department_id')->nullable();
        $table->string('job_title');
        $table->enum('employment_type', ['full_time', 'part_time', 'contract']);
        $table->date('join_date');
        $table->decimal('base_salary', 10, 2);
        
        // ข้อมูลธนาคาร
        $table->string('bank_name');
        $table->string('bank_account_number');
        
        // ข้อมูลฉุกเฉิน
        $table->string('emergency_contact_name');
        $table->string('emergency_contact_phone');
        
        // ข้อมูลอื่นๆ
        $table->string('profile_picture')->nullable();
        $table->enum('status', ['active', 'on_leave', 'terminated'])->default('active');
        
        $table->timestamps();
        $table->softDeletes();
    });
}

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
};
